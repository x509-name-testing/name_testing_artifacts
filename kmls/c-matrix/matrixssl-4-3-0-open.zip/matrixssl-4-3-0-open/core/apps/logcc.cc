/* The same facilities are also available from C++. */
#include "log.c"
