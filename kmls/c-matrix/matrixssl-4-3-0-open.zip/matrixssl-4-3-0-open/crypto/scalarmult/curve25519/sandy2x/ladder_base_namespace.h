#ifndef ladder_base_namespace_H
#define ladder_base_namespace_H

#define  ladder_base  psSodium_crypto_scalarmult_curve25519_sandy2x_ladder_base
#define _ladder_base _psSodium_crypto_scalarmult_curve25519_sandy2x_ladder_base

#endif /* ifndef ladder_base_namespace_H */

